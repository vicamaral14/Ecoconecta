<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>EcoConecta</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://unpkg.com/imask"></script>
    <style>
        .hidden { display: none !important; }
        .card-eco { background: var(--card-bg); color: var(--text); padding: 25px; border-radius: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); margin-top: 20px; }
        #status-gps { margin: 10px 0; font-size: 13px; color: #2e7d32; font-weight: bold; line-height: 1.4; }
        
        .tab-container { display: flex; margin-bottom: 15px; border-radius: 8px; overflow: hidden; border: 1px solid #ddd; }
        .tab-btn { flex: 1; padding: 10px; cursor: pointer; background: #f5f5f5; color: #333; text-align: center; font-weight: 600; border: none; transition: 0.3s; font-size: 12px; }
        .tab-btn.active { background: #2e7d32; color: #fff; }

        .item-mural { background: var(--card-bg); border: 1px solid #e0e0e0; padding: 20px; margin-bottom: 15px; border-radius: 12px; display: flex; flex-direction: column; justify-content: space-between; }
        .btn-acao { display: inline-flex; align-items: center; justify-content: center; padding: 10px 18px; border-radius: 8px; text-decoration: none; font-weight: 600; font-size: 14px; margin-top: 12px; margin-right: 8px; color: #fff !important; border: none; cursor: pointer; }
        .btn-mapa { background-color: #1976d2; }
        .btn-whats { background-color: #2e7d32; }
        .btn-perfil { background-color: #444; width: auto; padding: 8px 15px; margin-bottom: 0; }
        
        .secao-perfil { background: var(--bg); padding: 20px; border-radius: 10px; border: 1px solid #ddd; margin-bottom: 20px; }
        
        #modal-data { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; }
        .modal-content { background: var(--card-bg); padding: 20px; border-radius: 10px; width: 90%; max-width: 350px; }
        
        .filtro-container { background: #e8f5e9; padding: 15px; border-radius: 10px; margin-bottom: 20px; border: 1px solid #c8e6c9; }
        .dark-mode .filtro-container { background: #1b301c; border-color: #2e7d32; }
        .filtro-container label { font-weight: bold; color: #2e7d32; font-size: 14px; display: block; margin-bottom: 8px; }

        .theme-switch { position: fixed; bottom: 20px; right: 20px; z-index: 9999; background: var(--primary); color: white; border: none; padding: 10px; border-radius: 50%; width: 50px; height: 50px; cursor: pointer; box-shadow: 0 4px 15px rgba(0,0,0,0.3); font-size: 20px; display: flex; align-items: center; justify-content: center; }
        
        .grid-endereco { display: grid; grid-template-columns: 1fr 100px; gap: 10px; }
        .grid-cidade { display: grid; grid-template-columns: 1fr 60px; gap: 10px; }

        .scroll-container { max-height: 500px; overflow-y: auto; padding-right: 5px; margin-top: 10px; }
        .scroll-container::-webkit-scrollbar { width: 6px; }
        .scroll-container::-webkit-scrollbar-thumb { background: var(--primary); border-radius: 10px; }

        /* Estilos para Trocas */
        .troca-form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        .troca-seta { text-align: center; font-size: 28px; color: var(--primary); margin: 5px 0; font-weight: bold; }
        .badge-status { display: inline-block; padding: 3px 10px; border-radius: 20px; font-size: 12px; font-weight: bold; color: #fff; }
        .badge-aberta    { background: #2e7d32; }
        .badge-aceita    { background: #1976d2; }
        .badge-concluida { background: #555; }
        .badge-cancelada { background: #d32f2f; }
        .card-troca { background: var(--card-bg); border: 1px solid #e0e0e0; padding: 16px; margin-bottom: 14px; border-radius: 12px; border-left: 5px solid #2e7d32; }
        .card-troca.aceita    { border-left-color: #1976d2; }
        .card-troca.concluida { border-left-color: #555; }
        .card-troca.cancelada { border-left-color: #d32f2f; }

        /* Foto atual na edição */
        .foto-atual-edicao { margin-bottom: 10px; }
        .foto-atual-edicao img { max-width: 100%; max-height: 180px; border-radius: 8px; border: 2px solid #2e7d32; display: block; }
        .foto-atual-edicao p { font-size: 12px; color: #2e7d32; font-weight: bold; margin: 4px 0 6px 0; }
    </style>
</head>
<body>

<button class="theme-switch" onclick="toggleTheme()" title="Alternar Tema">🌓</button>

<div class="container">
    <header class="header-titulo-logos">
        <img src="images/CC.png" alt="Logo" class="logo">
        <h1>EcoConecta</h1>
        <img src="images/IFRS.png" alt="Logo" class="logo">
    </header>

    <div id="tela-login" class="card-eco">
        <h2 style="text-align:center">Entrar</h2>
        <input type="email" id="l_email" placeholder="E-mail">
        <input type="password" id="l_senha" placeholder="Senha">
        <button id="btn-login" onclick="fazerLogin()">
            <span class="spinner"></span> Acessar Sistema
        </button>
        <p style="text-align:center; font-size:14px;">Não tem conta? <a href="javascript:void(0)" onclick="alternar('tela-login', 'tela-cadastro')">Cadastre-se aqui</a></p>
    </div>


    <div id="tela-admin-dash" class="card-eco hidden">
        <h2>Gerenciar Materiais</h2>
        <div style="display:flex; gap:10px;">
            <input type="text" id="novo_material_nome" placeholder="Nome do Material (ex: Pilhas)">
            <button onclick="salvarMaterialAdmin()" style="width:120px">Adicionar</button>
        </div>
        <div id="lista-materiais-admin" style="margin-top:20px"></div>
        <button onclick="location.reload()" style="background:#888; margin-top:20px;">Sair do Admin</button>
    </div>

    <div id="tela-cadastro" class="card-eco hidden">
        <h2 style="text-align:center">Novo Cadastro</h2>
        <input type="text" id="c_nome" placeholder="Nome Completo / Razão Social">
        <input type="email" id="c_email" placeholder="E-mail">
        <input type="text" id="c_doc" placeholder="CPF ou CNPJ">
        <input type="text" id="c_tel" placeholder="WhatsApp (DDD + Número)">
        
        <div class="grid-endereco">
            <input type="text" id="c_rua" placeholder="Rua/Avenida">
            <input type="text" id="c_num" placeholder="Nº">
        </div>
        <input type="text" id="c_bairro" placeholder="Bairro">
        <div class="grid-cidade">
            <input type="text" id="c_cid" placeholder="Cidade">
            <input type="text" id="c_uf" placeholder="UF" maxlength="2">
        </div>
        <input type="text" id="c_cep" placeholder="CEP">

        <select id="c_tipo">
            <option value="Doador">Quero ser Doador</option>
            <option value="Coletor">Quero ser Coletor</option>
        </select>
        <input type="password" id="c_senha" placeholder="Crie uma senha">
        <button id="btn-cadastro" onclick="executarCadastro()">
            <span class="spinner"></span> Finalizar Cadastro
        </button>
        <p style="text-align:center;"><a href="javascript:void(0)" onclick="alternar('tela-cadastro', 'tela-login')">Voltar ao Login</a></p>
    </div>

    <div id="tela-doador" class="card-eco hidden">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
            <h2 id="boas-vindas" style="margin:0"></h2>
            <button class="btn-perfil" onclick="togglePerfil()">⚙️ Perfil</button>
        </div>

        <div id="area-perfil" class="hidden secao-perfil">
            <h3>Meus Dados</h3>
            <input type="text" id="p_nome" placeholder="Nome">
            <input type="email" id="p_email" placeholder="E-mail">
            <input type="text" id="p_tel" placeholder="WhatsApp">
            
            <div class="grid-endereco">
                <input type="text" id="p_rua" placeholder="Rua/Avenida">
                <input type="text" id="p_num" placeholder="Nº">
            </div>
            <input type="text" id="p_bairro" placeholder="Bairro">
            <div class="grid-cidade">
                <input type="text" id="p_cid" placeholder="Cidade">
                <input type="text" id="p_uf" placeholder="UF" maxlength="2">
            </div>
            <input type="text" id="p_cep" placeholder="CEP">

            <input type="password" id="p_senha" placeholder="Nova senha (deixe vazio para manter)">
            <button id="btn-salvar-perfil" onclick="salvarPerfil()" style="background:#2e7d32">
                <span class="spinner"></span> Salvar Alterações
            </button>
            <button onclick="togglePerfil()" style="background:#888">Cancelar</button>
            <button id="btn-excluir-conta" onclick="excluirConta()" style="background:#d32f2f; margin-top:20px">
                <span class="spinner"></span> Excluir Minha Conta
            </button>
        </div>

        <div id="conteudo-doador">
            <div id="area-doacao">
                <h3 id="titulo-doacao">O que você deseja doar?</h3>
                <select id="d_mat" onchange="toggleMaterialCustom()">
                    <option value="" disabled selected>Tipo de Material</option>
                </select>
                <input type="text" id="d_mat_custom" placeholder="Qual material?" class="hidden">
                
                <div style="display:flex; gap:10px;">
                    <input type="number" id="d_qtd" placeholder="Quantidade" style="flex:2">
                    <select id="d_unidade" style="flex:1">
                        <option value="kg">kg</option>
                        <option value="un">un</option>
                    </select>
                </div>

                <label style="font-weight:bold; display:block; margin-bottom:10px;">Local de Coleta:</label>
                <div class="tab-container">
                    <button id="tab-perfil" class="tab-btn active" onclick="mudarModoEnd('perfil')">Endereço Perfil</button>
                    <button id="tab-manual" class="tab-btn" onclick="mudarModoEnd('manual')">Manual</button>
                    <button id="tab-gps" class="tab-btn" onclick="mudarModoEnd('gps')">GPS</button>
                </div>
                
                <div id="form-perfil">
                    <textarea id="d_end_perfil" readonly style="background:var(--input-bg); color:var(--text); width:100%; border-radius:8px; padding:10px; border:1px solid var(--input-border);"></textarea>
                </div>
                <div id="form-manual" class="hidden">
                    <div class="grid-endereco">
                        <input type="text" id="d_rua" placeholder="Rua/Avenida">
                        <input type="text" id="d_num" placeholder="Nº">
                    </div>
                    <input type="text" id="d_bairro" placeholder="Bairro">
                    <div class="grid-cidade">
                        <input type="text" id="d_cid" placeholder="Cidade">
                        <input type="text" id="d_uf" placeholder="UF" maxlength="2">
                    </div>
                    <input type="text" id="d_cep" placeholder="CEP">
                </div>
                <div id="form-gps" class="hidden">
                    <button onclick="pegarGPS()" style="background:#444; margin-bottom:5px;">📍 Capturar Ponto pelo GPS</button>
                    <div id="status-gps">GPS não capturado</div>
                </div>

                <textarea id="d_obs" placeholder="Observações (ex: deixar no portão)..." style="width:100%; padding:10px; border-radius:8px; border:1px solid var(--input-border); margin-bottom:10px; background:var(--input-bg); color:var(--text);"></textarea>

                <label style="font-weight:bold; display:block; margin-bottom:6px;">📷 Foto do Material <span style="font-weight:normal; color:#888; font-size:13px;">(opcional)</span>:</label>

                <!-- Foto atual (visível apenas ao editar uma doação que já tem foto) -->
                <div id="d_foto_atual" class="foto-atual-edicao hidden">
                    <p>📌 Foto atual (será mantida se você não enviar uma nova):</p>
                    <img id="d_foto_atual_img" src="" alt="Foto atual da doação">
                </div>

                <input type="file" id="d_foto" accept="image/*" style="margin-bottom:14px;">
                <div id="d_foto_preview" style="display:none; margin-bottom:14px;">
                    <img id="d_foto_img" src="" alt="Preview" style="max-width:100%; max-height:200px; border-radius:8px; border:1px solid #ccc;">
                    <button type="button" onclick="removerFoto()" style="background:#d32f2f; width:auto; padding:5px 12px; font-size:12px; margin-top:6px;">🗑️ Remover Foto</button>
                </div>
                
                <input type="hidden" id="d_lat" value="null">
                <input type="hidden" id="d_lng" value="null">
                <input type="hidden" id="d_gps_cidade" value="">
                
                <button id="btn-enviar-doacao" onclick="enviarDoacao()" style="background:#2e7d32">
                    <span class="spinner"></span> Publicar Doação
                </button>
                <button id="btn-cancelar-edit" onclick="cancelarEdicao()" class="hidden" style="background:#888">Cancelar Edição</button>
            </div>

            <hr>
            <div class="tab-container" style="margin-top:20px;">
                <button id="tab-doa-ativas"     class="tab-btn active" onclick="alternarAbasDoador('ativas')">Doações em Andamento</button>
                <button id="tab-doa-concluidas" class="tab-btn"        onclick="alternarAbasDoador('concluidas')">Histórico de Concluídas</button>
                <button id="tab-doa-trocas"     class="tab-btn"        onclick="alternarAbasDoador('trocas')">♻️ Trocas</button>
            </div>

            <div id="aba-doacoes-ativas">
                <h3>Minhas Doações em Andamento</h3>
                <div id="lista-minhas-doacoes" class="scroll-container"></div>
            </div>

            <div id="aba-doacoes-concluidas" class="hidden">
                <h3>Meu Histórico de Doações Coletadas</h3>
                <div id="lista-minhas-doacoes-concluidas" class="scroll-container"></div>
            </div>

            <!-- ============================================================
                 ABA DE TROCAS DE MATERIAIS
                 ============================================================ -->
            <div id="aba-trocas" class="hidden">
                <h3>♻️ Trocas de Materiais</h3>
                <p style="font-size:13px; color:#666; margin-bottom:15px;">
                    Registre aqui o material que você tem disponível e o que deseja em troca. Outras entidades/doadores poderão demonstrar interesse.
                </p>

                <!-- Formulário de nova troca -->
                <div style="background:var(--bg); border:1px solid #c8e6c9; border-radius:10px; padding:15px; margin-bottom:20px;">
                    <h4 style="margin:0 0 12px 0; color:var(--primary);">Nova Proposta de Troca</h4>

                    <label style="font-weight:bold; font-size:13px; display:block; margin-bottom:6px;">📦 Ofereço:</label>
                    <div class="troca-form-grid">
                        <input type="text"   id="tr_mat_oferecido"  placeholder="Material que ofereço">
                        <div style="display:flex; gap:6px;">
                            <input type="number" id="tr_qtd_oferecida"   placeholder="Qtd" style="flex:2">
                            <select id="tr_unid_oferecida" style="flex:1">
                                <option value="kg">kg</option>
                                <option value="un">un</option>
                            </select>
                        </div>
                    </div>

                    <div class="troca-seta">⇅</div>

                    <label style="font-weight:bold; font-size:13px; display:block; margin-bottom:6px;">🔄 Desejo:</label>
                    <div class="troca-form-grid">
                        <input type="text"   id="tr_mat_desejado"   placeholder="Material que desejo">
                        <div style="display:flex; gap:6px;">
                            <input type="number" id="tr_qtd_desejada"    placeholder="Qtd" style="flex:2">
                            <select id="tr_unid_desejada" style="flex:1">
                                <option value="kg">kg</option>
                                <option value="un">un</option>
                            </select>
                        </div>
                    </div>

                    <textarea id="tr_obs" placeholder="Observações sobre a troca (opcional)..." style="width:100%; padding:10px; border-radius:8px; border:1px solid var(--input-border); margin-top:8px; background:var(--input-bg); color:var(--text);"></textarea>

                    <button id="btn-registrar-troca" onclick="registrarTroca()" style="background:#2e7d32; margin-top:6px;">
                        <span class="spinner"></span> Publicar Proposta de Troca
                    </button>
                </div>

                <!-- Sub-abas: Mural de Trocas / Minhas Trocas -->
                <div class="tab-container">
                    <button id="tab-troca-mural"  class="tab-btn active" onclick="alternarAbasTroca('mural')">Mural de Trocas</button>
                    <button id="tab-troca-minhas" class="tab-btn"        onclick="alternarAbasTroca('minhas')">Minhas Trocas</button>
                </div>

                <div id="aba-troca-mural">
                    <div class="filtro-container" style="margin-top:12px;">
                        <label>🔍 Filtrar Propostas:</label>
                        <input type="text" id="filtro-troca-mat-oferecido" placeholder="Material oferecido">
                        <input type="text" id="filtro-troca-mat-desejado" placeholder="Material desejado">
                        <select id="filtro-troca-unidade">
                            <option value="todos">Todas as Unidades</option>
                            <option value="kg">kg</option>
                            <option value="un">un</option>
                        </select>
                        <select id="filtro-troca-ordem">
                            <option value="recentes">Mais Recentes</option>
                            <option value="quantidade">Maior Quantidade</option>
                        </select>
                        <div style="display:flex; gap:10px; margin-top:10px;">
                            <button onclick="carregarTrocasAbertas()" style="flex:1;">🔍 Pesquisar</button>
                            <button onclick="resetarFiltrosTrocaMural()" style="background:#777; width:130px;">🔄 Limpar</button>
                        </div>
                    </div>
                    <div id="lista-trocas-abertas" class="scroll-container"></div>
                </div>

                <div id="aba-troca-minhas" class="hidden">
                    <div class="filtro-container" style="margin-top:12px;">
                        <label>🔍 Filtrar Minhas Trocas:</label>
                        <input type="text" id="filtro-minhas-trocas-mat" placeholder="Material (oferecido ou desejado)">
                        <select id="filtro-minhas-trocas-status">
                            <option value="todos">Todos os Status</option>
                            <option value="Aberta">Aberta</option>
                            <option value="Aceita">Aceita</option>
                            <option value="Concluída">Concluída</option>
                            <option value="Cancelada">Cancelada</option>
                        </select>
                        <select id="filtro-minhas-trocas-ordem">
                            <option value="recentes">Mais Recentes</option>
                            <option value="quantidade">Maior Quantidade</option>
                        </select>
                        <div style="display:flex; gap:10px; margin-top:10px;">
                            <button onclick="carregarMinhasTrocas()" style="flex:1;">🔍 Pesquisar</button>
                            <button onclick="resetarFiltrosMinhasTrocas()" style="background:#777; width:130px;">🔄 Limpar</button>
                        </div>
                    </div>
                    <div id="lista-minhas-trocas" class="scroll-container"></div>
                </div>
            </div>
            <!-- fim aba trocas -->

            <button onclick="location.reload()" style="background:#888; margin-top:20px;">Sair do Sistema</button>
        </div>
    </div>

    <div id="tela-coletor" class="card-eco hidden">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
            <h2 id="boas-vindas-col" style="margin:0"></h2>
            <button class="btn-perfil" onclick="togglePerfil()">⚙️ Perfil</button>
        </div>
        
        <div id="area-perfil-col"></div> 

        <div id="conteudo-coletor">
            <div class="tab-container">
                <button id="tab-col-mural" class="tab-btn active" onclick="alternarAbasColetor('mural')">Disponíveis para Coleta</button>
                <button id="tab-col-hist" class="tab-btn" onclick="alternarAbasColetor('historico')">Meu Histórico de Retiradas</button>
            </div>

            <div id="aba-mural">
                <div id="map-container" class="hidden">
                    <iframe id="mapa-iframe" width="100%" height="300px" frameborder="0" style="border:0; border-radius:10px; margin-bottom:15px;" allowfullscreen></iframe>
                </div>

               <div class="filtro-container">
    <label>Filtros de Pesquisa:</label>
    <select id="filtro-material">
        <option value="todos">Todos os Materiais</option>
    </select>
    <input type="text" id="filtro-cidade" placeholder="Cidade">
    <input type="number" id="filtro-qtd" placeholder="Quantidade mínima">
    <select id="filtro-unidade">
        <option value="todos">Todas Unidades</option>
        <option value="kg">kg</option>
        <option value="un">un</option>
    </select>
    <select id="filtro-ordem">
        <option value="recentes">Mais Recentes</option>
        <option value="quantidade">Maior Quantidade</option>
    </select>
    <div style="display:flex; gap:10px; margin-top:10px;">
        <button onclick="carregarMural()" style="flex:1;">🔍 Pesquisar</button>
        <button onclick="resetarFiltrosColetor()" style="background:#777; width:130px;">🔄 Limpar</button>
    </div>
</div>

                <div id="lista-mural" class="scroll-container"></div>
            </div>

            <div id="aba-historico" class="hidden">
                <div id="lista-historico-coletor" class="scroll-container"></div>
            </div>

            <button onclick="location.reload()" style="background:#888; margin-top:20px;">Sair do Sistema</button>
        </div>
    </div>
</div>

<div id="modal-data" class="hidden">
    <div class="modal-content">
        <h3>Agendar Coleta</h3>
        <p>Escolha o dia e horário:</p>
        <input type="datetime-local" id="data_reserva">
        <button id="btn-confirmar-reserva" onclick="confirmarReserva()" style="background:#2e7d32">
            <span class="spinner"></span> Confirmar Reserva
        </button>
        <button onclick="fecharModal()" style="background:#888">Cancelar</button>
    </div>
</div>

<script>
let user = null;
let editandoId = null;
let modoEndereco = 'perfil';
let idParaReservar = null;
let doacoesCache = {}; // Cache para objetos de doação — evita quebra do onclick com JSON especial

function validarCPF(cpf) {
    cpf = cpf.replace(/[^\d]+/g, ''); 
    if (cpf.length !== 11 || /^(\d)\1{10}$/.test(cpf)) return false; 
    let soma = 0, resto;
    for (let i = 1; i <= 9; i++) soma += parseInt(cpf.substring(i - 1, i)) * (11 - i);
    resto = (soma * 10) % 11;
    if ((resto === 10) || (resto === 11)) resto = 0;
    if (resto !== parseInt(cpf.substring(9, 10))) return false;
    soma = 0;
    for (let i = 1; i <= 10; i++) soma += parseInt(cpf.substring(i - 1, i)) * (12 - i);
    resto = (soma * 10) % 11;
    if ((resto === 10) || (resto === 11)) resto = 0;
    return resto === parseInt(cpf.substring(10, 11));
}

// Máscaras
const maskDoc     = IMask(document.getElementById('c_doc'),   { mask: [{mask:'000.000.000-00'}, {mask:'00.000.000/0000-00'}] });
const maskTel     = IMask(document.getElementById('c_tel'),   { mask: '(00) 00000-0000' });
const maskTelPerfil = IMask(document.getElementById('p_tel'), { mask: '(00) 00000-0000' });
const maskCepCad  = IMask(document.getElementById('c_cep'),   { mask: '00000-000' });
const maskCepPerf = IMask(document.getElementById('p_cep'),   { mask: '00000-000' });
const maskCepDoa  = IMask(document.getElementById('d_cep'),   { mask: '00000-000' });

// Preview da foto da doação (nova foto selecionada)
document.getElementById('d_foto').addEventListener('change', function() {
    const file = this.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = e => {
            document.getElementById('d_foto_img').src = e.target.result;
            document.getElementById('d_foto_preview').style.display = 'block';
        };
        reader.readAsDataURL(file);
    }
});

function removerFoto() {
    document.getElementById('d_foto').value = '';
    document.getElementById('d_foto_img').src = '';
    document.getElementById('d_foto_preview').style.display = 'none';
}

function initTheme() {
    const saved = localStorage.getItem('eco-theme') || 'light';
    if(saved === 'dark') document.body.classList.add('dark-mode');
}
function toggleTheme() {
    document.body.classList.toggle('dark-mode');
    localStorage.setItem('eco-theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
}
initTheme();

function setLoading(btnId, isLoading) {
    const btn = document.getElementById(btnId);
    if (!btn) return;
    btn.classList.toggle('loading', isLoading);
    btn.disabled = isLoading;
}

function alternar(s, e) { document.getElementById(s).classList.add('hidden'); document.getElementById(e).classList.remove('hidden'); }
function toggleMaterialCustom() { document.getElementById('d_mat_custom').classList.toggle('hidden', document.getElementById('d_mat').value !== 'outro'); }

function togglePerfil() {
    const estaOculto = document.getElementById('area-perfil').classList.contains('hidden');
    document.getElementById('area-perfil').classList.toggle('hidden');
    const telaConteudo = user.tipo_usuario === 'Coletor' ? 'conteudo-coletor' : 'conteudo-doador';
    document.getElementById(telaConteudo).classList.toggle('hidden', estaOculto);
}

function mudarModoEnd(modo) {
    modoEndereco = modo;
    ['perfil', 'manual', 'gps'].forEach(m => {
        const el = document.getElementById('tab-' + m);
        if(el) el.classList.toggle('active', modo === m);
        const form = document.getElementById('form-' + m);
        if(form) form.classList.toggle('hidden', modo !== m);
    });
    
    if(modo !== 'gps') {
        document.getElementById('d_lat').value = 'null';
        document.getElementById('d_lng').value = 'null';
        document.getElementById('d_gps_cidade').value = '';
        document.getElementById('status-gps').innerText = "GPS não capturado";
    }
}

function pegarGPS() {
    if (navigator.geolocation) {
        document.getElementById('status-gps').innerText = "Buscando sua localização...";
        navigator.geolocation.getCurrentPosition(async p => {
            const lat = p.coords.latitude;
            const lng = p.coords.longitude;
            document.getElementById('d_lat').value = lat;
            document.getElementById('d_lng').value = lng;
            
            try {
                const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=10&addressdetails=1`, {
                    headers: { 'Accept-Language': 'pt-BR' }
                });
                const data = await response.json();
                
                let cidade = data.address.city || data.address.town || data.address.village || data.address.municipality || "Desconhecido";
                let estado = data.address.state ? data.address.state : "";
                
                const estadosSiglas = {
                    "Acre":"AC","Alagoas":"AL","Amapá":"AP","Amazonas":"AM","Bahia":"BA","Ceará":"CE","Distrito Federal":"DF",
                    "Espírito Santo":"ES","Goiás":"GO","Maranhão":"MA","Mato Grosso":"MT","Mato Grosso do Sul":"MS","Minas Gerais":"MG",
                    "Pará":"PA","Paraíba":"PB","Paraná":"PR","Pernambuco":"PE","Piauí":"PI","Rio de Janeiro":"RJ","Rio Grande do Norte":"RN",
                    "Rio Grande do Sul":"RS","Rondônia":"RO","Roraima":"RR","Santa Catarina":"SC","São Paulo":"SP","Sergipe":"SE","Tocantins":"TO"
                };
                let uf = estadosSiglas[estado] || estado;
                let localFormatado = uf ? `${cidade} / ${uf}` : cidade;
                document.getElementById('d_gps_cidade').value = localFormatado;
                document.getElementById('status-gps').innerHTML = `✅ Localizado: ${localFormatado} | <a href="https://maps.google.com/?q=${lat},${lng}" target="_blank" style="color:#1976d2">Ver no Maps</a>`;
            } catch (err) {
                document.getElementById('d_gps_cidade').value = "Coordenadas GPS";
                document.getElementById('status-gps').innerHTML = `✅ Localizado! <a href="https://maps.google.com/?q=${lat},${lng}" target="_blank" style="color:#1976d2">Ver no Maps</a>`;
            }
        }, () => alert("Por favor, ative seu GPS."));
    }
}

function formatarEndereco(rua, num, bairro, cid, uf, cep) {
    return `${rua}, ${num}, ${bairro}, ${cid}, ${uf}, ${cep}`;
}

function parseEndereco(str) {
    if(!str) return {rua:'', num:'', bairro:'', cid:'', uf:'', cep:''};
    const parts = str.split(',').map(s => s.trim());
    return { rua: parts[0]||'', num: parts[1]||'', bairro: parts[2]||'', cid: parts[3]||'', uf: parts[4]||'', cep: parts[5]||'' };
}

async function fazerLogin() {
    setLoading('btn-login', true);
    const fd = new FormData();
    fd.append('acao', 'login');
    fd.append('email', document.getElementById('l_email').value);
    fd.append('senha', document.getElementById('l_senha').value);
    
    try {
        const r = await fetch('salvar.php', { method: 'POST', body: fd });
        const res = await r.json();
        
        if(res.id_usuario) {
            user = res;
            user.id = res.id_usuario;
            // Se for Admin, joga pro painel e para a função
            if (user.tipo_usuario === 'Admin') {
                alternar('tela-login', 'tela-admin-dash');
                carregarMateriaisAdmin();
                setLoading('btn-login', false);
                return;
            }
            
            document.getElementById('p_nome').value = user.nome;
            document.getElementById('p_email').value = user.email;
            maskTelPerfil.value = user.telefone;
            
            const endObj = parseEndereco(user.endereco);
            document.getElementById('p_rua').value    = endObj.rua;
            document.getElementById('p_num').value    = endObj.num;
            document.getElementById('p_bairro').value = endObj.bairro;
            document.getElementById('p_cid').value    = endObj.cid;
            document.getElementById('p_uf').value     = endObj.uf;
            maskCepPerf.value = endObj.cep;

            document.getElementById('d_end_perfil').value = user.endereco;

            await carregarMateriaisAdmin();

            if (user.tipo_usuario === 'Coletor') {
                document.getElementById('boas-vindas-col').innerText = "Olá, " + user.nome;
                document.getElementById('area-perfil-col').appendChild(document.getElementById('area-perfil'));
                alternar('tela-login', 'tela-coletor');
                carregarMural();
                carregarHistoricoColetor();
            } else {
                document.getElementById('boas-vindas').innerText = "Olá, " + user.nome;
                alternar('tela-login', 'tela-doador');
                carregarMinhasDoacoes();
                carregarMinhasDoacoesConcluidas();
            }
        } else alert(res.erro);
    } catch (e) { alert("Erro de conexão."); }
    setLoading('btn-login', false);
}

function alternarAbasColetor(aba) {
    document.getElementById('aba-mural').classList.toggle('hidden', aba !== 'mural');
    document.getElementById('aba-historico').classList.toggle('hidden', aba !== 'historico');
    document.getElementById('tab-col-mural').classList.toggle('active', aba === 'mural');
    document.getElementById('tab-col-hist').classList.toggle('active', aba === 'historico');
}

function alternarAbasDoador(aba) {
    document.getElementById('aba-doacoes-ativas').classList.toggle('hidden', aba !== 'ativas');
    document.getElementById('aba-doacoes-concluidas').classList.toggle('hidden', aba !== 'concluidas');
    document.getElementById('aba-trocas').classList.toggle('hidden', aba !== 'trocas');
    document.getElementById('tab-doa-ativas').classList.toggle('active', aba === 'ativas');
    document.getElementById('tab-doa-concluidas').classList.toggle('active', aba === 'concluidas');
    document.getElementById('tab-doa-trocas').classList.toggle('active', aba === 'trocas');

    if (aba === 'trocas') {
        carregarTrocasAbertas();
        carregarMinhasTrocas();
    }
}

function alternarAbasTroca(aba) {
    document.getElementById('aba-troca-mural').classList.toggle('hidden', aba !== 'mural');
    document.getElementById('aba-troca-minhas').classList.toggle('hidden', aba !== 'minhas');
    document.getElementById('tab-troca-mural').classList.toggle('active', aba === 'mural');
    document.getElementById('tab-troca-minhas').classList.toggle('active', aba === 'minhas');
}

function resetarFiltrosColetor() {
    document.getElementById('filtro-material').value = 'todos';
    document.getElementById('filtro-cidade').value = '';
    document.getElementById('filtro-qtd').value = '';
    document.getElementById('filtro-unidade').value = 'todos';
    document.getElementById('filtro-ordem').value = 'recentes';
    carregarMural();
}

async function enviarDoacao() {
    if(!document.getElementById('d_mat').value) return alert("Selecione o tipo de material!");
    setLoading('btn-enviar-doacao', true);
    
    const fd = new FormData();
    fd.append('acao', 'doacao'); 
    fd.append('id_user', user.id);
    if(editandoId) fd.append('id_doacao', editandoId);
    
    fd.append('mat', document.getElementById('d_mat').value);
    fd.append('mat_custom', document.getElementById('d_mat_custom').value);
    fd.append('qtd', document.getElementById('d_qtd').value);
    fd.append('unidade', document.getElementById('d_unidade').value);
    
    let enderecoFinal = "";
    if(modoEndereco === 'perfil') {
        enderecoFinal = user.endereco;
    } else if(modoEndereco === 'manual') {
        enderecoFinal = formatarEndereco(
            document.getElementById('d_rua').value,
            document.getElementById('d_num').value,
            document.getElementById('d_bairro').value,
            document.getElementById('d_cid').value,
            document.getElementById('d_uf').value,
            maskCepDoa.value
        );
    } else {
        enderecoFinal = document.getElementById('d_gps_cidade').value || "Coordenadas GPS";
    }

    fd.append('end', enderecoFinal);
    fd.append('obs', document.getElementById('d_obs').value);
    fd.append('lat', document.getElementById('d_lat').value);
    fd.append('lng', document.getElementById('d_lng').value);

    // Foto opcional — só envia se o usuário selecionou um novo arquivo
    const fotoInput = document.getElementById('d_foto');
    if (fotoInput.files.length > 0) {
        fd.append('foto', fotoInput.files[0]);
    }

    try {
        const r = await fetch('salvar.php', { method: 'POST', body: fd });
        const res = await r.json();
        if(res.sucesso) { 
            alert(res.sucesso); 
            limparFormulario(); 
            carregarMinhasDoacoes();
            carregarMinhasDoacoesConcluidas();
        } else alert(res.erro);
    } catch (e) { alert("Erro ao salvar."); }
    setLoading('btn-enviar-doacao', false);
}

function limparFormulario() {
    editandoId = null;
    document.getElementById('titulo-doacao').innerText = "O que você deseja doar?";
    document.getElementById('btn-enviar-doacao').innerText = "Publicar Doação";
    document.getElementById('btn-cancelar-edit').classList.add('hidden');
    
    document.getElementById('d_mat').value = "";
    document.getElementById('d_mat_custom').value = '';
    document.getElementById('d_qtd').value = '';
    document.getElementById('d_obs').value = '';
    
    document.getElementById('d_rua').value = '';
    document.getElementById('d_num').value = '';
    document.getElementById('d_bairro').value = '';
    document.getElementById('d_cid').value = '';
    document.getElementById('d_uf').value = '';
    maskCepDoa.value = '';
    
    document.getElementById('d_lat').value = 'null';
    document.getElementById('d_lng').value = 'null';
    document.getElementById('d_gps_cidade').value = '';
    document.getElementById('status-gps').innerText = "GPS não capturado";

    // Reset foto nova
    document.getElementById('d_foto').value = '';
    document.getElementById('d_foto_img').src = '';
    document.getElementById('d_foto_preview').style.display = 'none';

    // Esconde foto atual (modo edição)
    document.getElementById('d_foto_atual').classList.add('hidden');
    document.getElementById('d_foto_atual_img').src = '';

    mudarModoEnd('perfil');
    toggleMaterialCustom();
}

async function carregarMinhasDoacoes() {
    const fd = new FormData();
    fd.append('acao', 'minhas_doacoes');
    fd.append('id_user', user.id);
    const r = await fetch('salvar.php', { method: 'POST', body: fd });
    const dados = await r.json();
    const lista = document.getElementById('lista-minhas-doacoes');
    lista.innerHTML = dados.length ? "" : "<p>Você ainda não tem doações em andamento.</p>";
    dados.forEach(d => {
        const material = d.id_material ? d.nome_material : d.material_personalizado;
        let localInfo = d.endereco_manual;
        let gpsBtn = '';

        if(d.latitude && d.latitude !== 'null' && d.latitude !== '0') {
            gpsBtn = `<a href="https://maps.google.com/?q=${d.latitude},${d.longitude}" target="_blank" class="btn-acao btn-mapa" style="padding:5px 10px; font-size:12px">Ver no Mapa</a>`;
        } else {
            gpsBtn = `<a href="https://maps.google.com/?q=${encodeURIComponent(d.endereco_manual)}" target="_blank" class="btn-acao btn-mapa" style="padding:5px 10px; font-size:12px">Ver no Mapa</a>`;
        }

        let obsHtml = d.observacoes ? `<div style="margin-top:8px; padding:8px; background:var(--bg); border:1px solid #eee; border-radius:5px; font-size:13px; color:var(--text);"><b>Obs:</b> ${d.observacoes}</div>` : '';
        let fotoHtml = d.foto_url ? `<div style="margin-top:10px;"><img src="${d.foto_url}" alt="Foto do material" style="max-width:100%; max-height:200px; border-radius:8px; border:1px solid #ccc; display:block;"></div>` : '';

        // Armazena no cache para edição segura
        doacoesCache[d.id_doacao] = d;

        lista.innerHTML += `<div style="background:var(--card-bg); padding:15px; margin-bottom:10px; border-radius:8px; border-left:5px solid #2e7d32">
            <strong>${material}</strong> (${d.quantidade}${d.unidade_medida})<br>
            <small>Local: ${localInfo}</small><br>
            <small>Status: <b>${d.status_doacao}</b></small>
            ${obsHtml}
            ${fotoHtml}
            <div style="margin-top:10px">
                ${d.status_doacao === 'Disponível' ? `
                    <button onclick='prepararEdicao(${d.id_doacao})' style="padding:5px 10px; font-size:12px; margin-right:5px; width:auto; display:inline-block">✏️ Editar</button>
                    <button onclick='excluirDoacao(${d.id_doacao})' style="padding:5px 10px; font-size:12px; background:#d32f2f; color:white; border:none; border-radius:5px; width:auto; display:inline-block">🗑️ Excluir</button>
                ` : ''}
                ${gpsBtn}
            </div>
        </div>`;
    });
}

async function carregarMinhasDoacoesConcluidas() {
    const fd = new FormData();
    fd.append('acao', 'minhas_doacoes_concluidas');
    fd.append('id_user', user.id);
    const r = await fetch('salvar.php', { method: 'POST', body: fd });
    const dados = await r.json();
    const lista = document.getElementById('lista-minhas-doacoes-concluidas');
    lista.innerHTML = dados.length ? "" : "<p>Você ainda não tem doações coletadas no histórico.</p>";
    dados.forEach(d => {
        const material = d.id_material ? d.nome_material : d.material_personalizado;
        let gpsBtn = '';

        if(d.latitude && d.latitude !== 'null' && d.latitude !== '0') {
            gpsBtn = `<a href="https://maps.google.com/?q=${d.latitude},${d.longitude}" target="_blank" class="btn-acao btn-mapa" style="padding:5px 10px; font-size:12px">Ver no Mapa</a>`;
        } else {
            gpsBtn = `<a href="https://maps.google.com/?q=${encodeURIComponent(d.endereco_manual)}" target="_blank" class="btn-acao btn-mapa" style="padding:5px 10px; font-size:12px">Ver no Mapa</a>`;
        }

        const dataFmt = new Date(d.data_conclusao_coleta).toLocaleString('pt-BR');
        let obsHtml = d.observacoes ? `<div style="margin-top:8px; padding:8px; background:var(--bg); border:1px solid #eee; border-radius:5px; font-size:13px; color:var(--text);"><b>Obs:</b> ${d.observacoes}</div>` : '';
        let fotoHtml = d.foto_url ? `<div style="margin-top:10px;"><img src="${d.foto_url}" alt="Foto do material" style="max-width:100%; max-height:200px; border-radius:8px; border:1px solid #ccc; display:block;"></div>` : '';
        
        lista.innerHTML += `<div style="background:var(--card-bg); padding:15px; margin-bottom:10px; border-radius:8px; border-left:5px solid #1976d2">
            <strong>${material}</strong> (${d.quantidade}${d.unidade_medida})<br>
            <small>Local: ${d.endereco_manual}</small><br>
            <small>Coletado em: <b>${dataFmt}</b></small>
            ${obsHtml}
            ${fotoHtml}
            <div style="margin-top:10px">${gpsBtn}</div>
        </div>`;
    });
}

async function carregarMural() {
    const filtro  = document.getElementById('filtro-material').value;
    const cidade  = document.getElementById('filtro-cidade').value;
    const qtd     = document.getElementById('filtro-qtd').value;
    const unidad  = document.getElementById('filtro-unidade').value;
    const ordem   = document.getElementById('filtro-ordem').value;

    const fd = new FormData();
    fd.append('acao', 'buscar_mural');
    fd.append('material', filtro);
    fd.append('cidade', cidade);
    fd.append('qtd', qtd);
    fd.append('unidade', unidad);
    fd.append('ordem', ordem);

    const r = await fetch('salvar.php', { method: 'POST', body: fd });
    let dados = await r.json();

    const mapContainer = document.getElementById('map-container');
    const iframe = document.getElementById('mapa-iframe');
    
    if (dados.length > 0) {
        mapContainer.classList.remove('hidden');
        const dComGps = dados.find(d => d.latitude && d.latitude !== 'null' && d.latitude !== '0');
        let query = dComGps ? `${dComGps.latitude},${dComGps.longitude}` : (dados[0].endereco_manual || "Brasil");
        iframe.src = `https://maps.google.com/maps?q=${encodeURIComponent(query)}&t=&z=13&ie=UTF8&iwloc=&output=embed`;
    }

    const mural = document.getElementById('lista-mural');
    mural.innerHTML = dados.length ? "" : "<p style='text-align:center; padding:20px;'>Nenhum material disponível para este filtro.</p>";
    
    dados.forEach(d => {
        const material = d.id_material ? d.nome_material : d.material_personalizado;
        let infoEndereco = `<b>Endereço:</b> ${d.endereco_manual}`;
        let linkMapa = `<a href="https://maps.google.com/?q=${encodeURIComponent(d.endereco_manual)}" target="_blank" class="btn-acao btn-mapa">📍 Abrir Mapa</a>`;

        if (d.latitude && d.latitude !== 'null' && d.latitude !== '0') {
            linkMapa = `<a href="https://maps.google.com/?q=${d.latitude},${d.longitude}" target="_blank" class="btn-acao btn-mapa">📍 Abrir Navegação</a>`;
        }

        let acoes = '';
        if (d.status_doacao === 'Disponível') {
            acoes = `<button class="btn-acao btn-whats" onclick="reservar(${d.id_doacao})">📦 Reservar</button>
                     <a href="https://wa.me/55${d.telefone}" target="_blank" class="btn-acao btn-whats" style="background:#25d366">💬 WhatsApp</a> ${linkMapa}`;
        } else if (d.status_doacao === 'Reservado' && d.id_coletor == user.id) {
            acoes = `<button class="btn-acao btn-whats" onclick="concluir(${d.id_doacao})">✅ Coletado</button>
                     <p style="color:#d32f2f; font-weight:bold; margin-top:10px">Sua reserva para: ${new Date(d.data_coleta_prevista).toLocaleString('pt-BR')}</p> ${linkMapa}`;
        } else {
            acoes = `<p style="color:#666; margin-top:10px"><i>Reservado por outro coletor para: ${new Date(d.data_coleta_prevista).toLocaleString('pt-BR')}</i></p>`;
        }

        let fotoMural = d.foto_url ? `<div style="margin:10px 0;"><img src="${d.foto_url}" alt="Foto do material" style="max-width:100%; max-height:200px; border-radius:8px; border:1px solid #ccc; display:block;"></div>` : '';

        mural.innerHTML += `
            <div class="item-mural">
                <div>
                    <strong style="font-size:18px; color:#2e7d32;">${material}</strong> - ${d.quantidade}${d.unidade_medida}
                    <p style="font-size:14px; margin:10px 0;"><b>Doador:</b> ${d.doador_nome}<br>${infoEndereco}</p>
                    <p style="font-size:12px; color:#666">${d.observacoes || ""}</p>
                    ${fotoMural}
                </div>
                <div>${acoes}</div>
            </div>`;
    });
}

async function carregarHistoricoColetor() {
    const fd = new FormData();
    fd.append('acao', 'historico_coletor');
    fd.append('id_user', user.id);
    const r = await fetch('salvar.php', { method: 'POST', body: fd });
    const dados = await r.json();
    const lista = document.getElementById('lista-historico-coletor');
    lista.innerHTML = dados.length ? "" : "<p style='text-align:center; padding:20px;'>Você ainda não concluído nenhuma coleta.</p>";
    
    dados.forEach(d => {
        const material = d.id_material ? d.nome_material : d.material_personalizado;
        const dataConclusao = new Date(d.data_conclusao_coleta).toLocaleString('pt-BR');
        
        lista.innerHTML += `<div style="background:var(--card-bg); padding:15px; margin-bottom:10px; border-radius:8px; border-left:5px solid #1976d2">
            <strong style="color:#1976d2">${material}</strong> (${d.quantidade}${d.unidade_medida})<br>
            <small>Doador: ${d.doador_nome}</small><br>
            <small>Retirado em: <b>${dataConclusao}</b></small>
            ${d.foto_url ? `<div style="margin-top:10px;"><img src="${d.foto_url}" alt="Foto do material" style="max-width:100%; max-height:180px; border-radius:8px; border:1px solid #ccc; display:block;"></div>` : ''}
        </div>`;
    });
}

async function salvarPerfil() {
    setLoading('btn-salvar-perfil', true);
    
    const novoEmail = document.getElementById('p_email').value;
    const novaSenha = document.getElementById('p_senha').value;
    const novoEnd = formatarEndereco(
        document.getElementById('p_rua').value,
        document.getElementById('p_num').value,
        document.getElementById('p_bairro').value,
        document.getElementById('p_cid').value,
        document.getElementById('p_uf').value,
        maskCepPerf.value
    );

    const fd = new FormData();
    fd.append('acao', 'perfil_update');
    fd.append('id', user.id);
    fd.append('nome', document.getElementById('p_nome').value);
    fd.append('email', novoEmail);
    fd.append('tel', maskTelPerfil.unmaskedValue);
    fd.append('end', novoEnd);
    fd.append('senha', novaSenha);

    try {
        const r = await fetch('salvar.php', { method: 'POST', body: fd });
        const res = await r.json();
        if(res.sucesso) {
            alert(res.sucesso);
            if (novoEmail !== user.email || novaSenha !== "") {
                alert("Por segurança, acesse novamente com seus novos dados.");
                location.reload();
            } else {
                user.nome = document.getElementById('p_nome').value;
                user.endereco = novoEnd;
                user.telefone = maskTelPerfil.unmaskedValue;
                document.getElementById('d_end_perfil').value = user.endereco;
                if(user.tipo_usuario === 'Coletor'){
                    document.getElementById('boas-vindas-col').innerText = "Olá, " + user.nome;
                } else {
                    document.getElementById('boas-vindas').innerText = "Olá, " + user.nome;
                }
                togglePerfil();
            }
        } else alert(res.erro);
    } catch (e) { alert("Erro ao atualizar."); }
    setLoading('btn-salvar-perfil', false);
}

/**
 * prepararEdicao — recebe o id_doacao (número), busca do cache e preenche o formulário.
 * A foto atual é exibida em um bloco separado; o input de arquivo fica vazio para o usuário
 * enviar uma nova foto somente se quiser substituir.
 */
function prepararEdicao(id) {
    const d = doacoesCache[id];
    if (!d) return alert("Erro ao carregar dados da doação. Recarregue a lista.");

    editandoId = d.id_doacao;
    document.getElementById('titulo-doacao').innerText = "✏️ Editando Doação";
    document.getElementById('d_mat').value     = d.id_material || 'outro';
    document.getElementById('d_mat_custom').value = d.material_personalizado || '';
    document.getElementById('d_qtd').value     = d.quantidade;
    document.getElementById('d_unidade').value = d.unidade_medida;
    document.getElementById('d_obs').value     = d.observacoes || '';
    
    const end = parseEndereco(d.endereco_manual);
    document.getElementById('d_rua').value    = end.rua;
    document.getElementById('d_num').value    = end.num;
    document.getElementById('d_bairro').value = end.bairro;
    document.getElementById('d_cid').value    = end.cid;
    document.getElementById('d_uf').value     = end.uf;
    maskCepDoa.value = end.cep;

    // Exibe foto atual se a doação já tiver uma
    const fotoAtualDiv = document.getElementById('d_foto_atual');
    const fotoAtualImg = document.getElementById('d_foto_atual_img');
    if (d.foto_url) {
        fotoAtualImg.src = d.foto_url;
        fotoAtualDiv.classList.remove('hidden');
    } else {
        fotoAtualImg.src = '';
        fotoAtualDiv.classList.add('hidden');
    }

    // Limpa o input de arquivo e o preview — usuário só envia nova foto se quiser trocar
    document.getElementById('d_foto').value = '';
    document.getElementById('d_foto_img').src = '';
    document.getElementById('d_foto_preview').style.display = 'none';

    document.getElementById('btn-enviar-doacao').innerText = "Salvar Alterações";
    document.getElementById('btn-cancelar-edit').classList.remove('hidden');
    mudarModoEnd(d.latitude && d.latitude !== 'null' ? 'gps' : 'manual');
    toggleMaterialCustom();
    window.scrollTo(0, 0);
}

async function executarCadastro() {
    const nome = document.getElementById('c_nome').value.trim();
    const email = document.getElementById('c_email').value.trim();
    const doc = maskDoc.unmaskedValue;
    const tel = maskTel.unmaskedValue;
    const senha = document.getElementById('c_senha').value.trim();

    if (!nome || !email || !doc || !tel || !senha) {
        return alert("⚠️ Preencha todos os campos obrigatórios.");
    }
    if (doc.length === 11 && !validarCPF(doc)) {
        return alert("❌ CPF inválido.");
    }

    setLoading('btn-cadastro', true);
    const endFull = formatarEndereco(
        document.getElementById('c_rua').value, document.getElementById('c_num').value,
        document.getElementById('c_bairro').value, document.getElementById('c_cid').value,
        document.getElementById('c_uf').value, maskCepCad.value
    );

    const fd = new FormData(); fd.append('acao', 'cadastro');
    fd.append('nome', nome); fd.append('email', email); fd.append('doc', doc);
    fd.append('tel', tel); fd.append('end', endFull);
    fd.append('tipo', document.getElementById('c_tipo').value); fd.append('senha', senha);
    
    try {
        const r = await fetch('salvar.php', { method: 'POST', body: fd });
        const res = await r.json();
        if (res.sucesso) { alert(res.sucesso); location.reload(); } 
        else { alert("Erro ao cadastrar: " + res.erro); }
    } catch (e) { alert("Falha no servidor."); }
    setLoading('btn-cadastro', false);
}

function loginAdmin() {
    const e = document.getElementById('adm_email').value;
    const s = document.getElementById('adm_senha').value;
    if(e === 'admin@gmail.com' && s === '123') { alternar('tela-admin-login', 'tela-admin-dash'); carregarMateriaisAdmin(); }
    else alert("Dados inválidos!");
}

async function carregarMateriaisAdmin() {
    const fd = new FormData(); 
    fd.append('acao', 'adm_listar_materiais');
    const r = await fetch('salvar.php', { method:'POST', body:fd });
    const dados = await r.json();
    const lista = document.getElementById('lista-materiais-admin'); 
    if(lista) {
        lista.innerHTML = "";
        dados.forEach(m => {
            lista.innerHTML += `<div style="display:flex; justify-content:space-between; padding:10px; border-bottom:1px solid #ddd">
                <span>${m.nome_material}</span>
                <button onclick="excluirMaterialAdmin(${m.id_material})" style="width:auto; padding:5px 10px; background:#d32f2f">Excluir</button>
            </div>`;
        });
    }
    atualizarSelectsMateriais(dados);
}

function atualizarSelectsMateriais(dados) {
    [document.getElementById('d_mat'), document.getElementById('filtro-material')].forEach((s, idx) => {
        if(!s) return;
        const val = s.value;
        s.innerHTML = idx === 0 ? '<option value="" disabled selected>Tipo de Material</option>' : '<option value="todos">Todos os Materiais</option>';
        dados.forEach(m => s.innerHTML += `<option value="${m.id_material}">${m.nome_material}</option>`);
        if(idx === 0) s.innerHTML += '<option value="outro">Outro Material</option>';
        s.value = val;
    });
}

async function salvarMaterialAdmin() {
    const nome = document.getElementById('novo_material_nome').value;
    if(!nome) return;
    const fd = new FormData();
    fd.append('acao', 'adm_salvar_material');
    fd.append('nome', nome);
    await fetch('salvar.php', { method:'POST', body:fd });
    document.getElementById('novo_material_nome').value = "";
    carregarMateriaisAdmin();
}

async function excluirMaterialAdmin(id) {
    if(!confirm("Excluir material?")) return;
    const fd = new FormData();
    fd.append('acao', 'adm_excluir_material');
    fd.append('id', id);
    await fetch('salvar.php', { method:'POST', body:fd });
    carregarMateriaisAdmin();
}

function reservar(id) { idParaReservar = id; document.getElementById('modal-data').classList.remove('hidden'); }
function fecharModal() { document.getElementById('modal-data').classList.add('hidden'); }

async function confirmarReserva() {
    const data = document.getElementById('data_reserva').value;
    if(!data) return alert("Selecione data!");
    setLoading('btn-confirmar-reserva', true);
    const fd = new FormData();
    fd.append('acao', 'reservar');
    fd.append('id_user', user.id);
    fd.append('id_doacao', idParaReservar);
    fd.append('data', data);
    try {
        const r = await fetch('salvar.php', { method: 'POST', body: fd });
        if((await r.json()).sucesso) { fecharModal(); carregarMural(); }
    } catch (e) { alert("Erro ao reservar."); }
    setLoading('btn-confirmar-reserva', false);
}

async function concluir(id) {
    if(!confirm("Confirmar coleta?")) return;
    const fd = new FormData();
    fd.append('acao', 'concluir');
    fd.append('id_user', user.id);
    fd.append('id_doacao', id);
    await fetch('salvar.php', { method: 'POST', body: fd }); 
    carregarMural();
    carregarHistoricoColetor();
}

async function excluirDoacao(id) {
    if(!confirm("Deseja apagar?")) return;
    const fd = new FormData();
    fd.append('acao', 'excluir_doacao');
    fd.append('id_user', user.id);
    fd.append('id_doacao', id);
    await fetch('salvar.php', { method: 'POST', body: fd });
    carregarMinhasDoacoes();
}

async function excluirConta() {
    if(!confirm("TEM CERTEZA?")) return;
    setLoading('btn-excluir-conta', true);
    const fd = new FormData();
    fd.append('acao', 'perfil_excluir');
    fd.append('id', user.id);
    await fetch('salvar.php', { method: 'POST', body: fd });
    location.reload();
}

function cancelarEdicao() { limparFormulario(); }

function resetarFiltrosTrocaMural() {
    document.getElementById('filtro-troca-mat-oferecido').value = '';
    document.getElementById('filtro-troca-mat-desejado').value = '';
    document.getElementById('filtro-troca-unidade').value = 'todos';
    document.getElementById('filtro-troca-ordem').value = 'recentes';
    carregarTrocasAbertas();
}

function resetarFiltrosMinhasTrocas() {
    document.getElementById('filtro-minhas-trocas-mat').value = '';
    document.getElementById('filtro-minhas-trocas-status').value = 'todos';
    document.getElementById('filtro-minhas-trocas-ordem').value = 'recentes';
    carregarMinhasTrocas();
}

// =====================================================
// FUNÇÕES DE TROCA DE MATERIAIS
// =====================================================

async function registrarTroca() {
    const matOferec = document.getElementById('tr_mat_oferecido').value.trim();
    const qtdOferec = document.getElementById('tr_qtd_oferecida').value;
    const matDesej  = document.getElementById('tr_mat_desejado').value.trim();
    const qtdDesej  = document.getElementById('tr_qtd_desejada').value;

    if (!matOferec || !qtdOferec || !matDesej || !qtdDesej) {
        return alert("Preencha todos os campos obrigatórios da troca (materiais e quantidades).");
    }

    setLoading('btn-registrar-troca', true);
    const fd = new FormData();
    fd.append('acao', 'registrar_troca');
    fd.append('id_user', user.id);
    fd.append('mat_oferecido',    matOferec);
    fd.append('qtd_oferecida',    qtdOferec);
    fd.append('unidade_oferecida', document.getElementById('tr_unid_oferecida').value);
    fd.append('mat_desejado',     matDesej);
    fd.append('qtd_desejada',     qtdDesej);
    fd.append('unidade_desejada', document.getElementById('tr_unid_desejada').value);
    fd.append('obs', document.getElementById('tr_obs').value);

    try {
        const r = await fetch('salvar.php', { method: 'POST', body: fd });
        const res = await r.json();
        if (res.sucesso) {
            alert(res.sucesso);
            document.getElementById('tr_mat_oferecido').value = '';
            document.getElementById('tr_qtd_oferecida').value = '';
            document.getElementById('tr_mat_desejado').value  = '';
            document.getElementById('tr_qtd_desejada').value  = '';
            document.getElementById('tr_obs').value = '';
            carregarTrocasAbertas();
            carregarMinhasTrocas();
        } else {
            alert(res.erro);
        }
    } catch(e) { alert("Erro ao registrar troca."); }
    setLoading('btn-registrar-troca', false);
}

async function carregarTrocasAbertas() {
    const fd = new FormData();
    fd.append('acao', 'listar_trocas_abertas');
    fd.append('id_user', user.id);
    fd.append('mat_oferecido', document.getElementById('filtro-troca-mat-oferecido').value);
    fd.append('mat_desejado',  document.getElementById('filtro-troca-mat-desejado').value);
    fd.append('unidade',       document.getElementById('filtro-troca-unidade').value);
    fd.append('ordem',         document.getElementById('filtro-troca-ordem').value);

    const r = await fetch('salvar.php', { method: 'POST', body: fd });
    const dados = await r.json();
    const lista = document.getElementById('lista-trocas-abertas');

    if (!dados.length) {
        lista.innerHTML = "<p style='text-align:center; padding:20px; color:#666;'>Nenhuma proposta de troca disponível no momento.</p>";
        return;
    }

    lista.innerHTML = "";
    dados.forEach(t => {
        const dataFmt = new Date(t.data_troca).toLocaleDateString('pt-BR');
        lista.innerHTML += `
        <div class="card-troca">
            <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:6px;">
                <div>
                    <strong style="color:#2e7d32; font-size:15px;">
                        📦 ${t.material_oferecido} (${t.qtd_oferecida} ${t.unidade_oferecida})
                    </strong><br>
                    <span style="font-size:13px; color:#555;">⇅ por <strong>${t.material_desejado}</strong> (${t.qtd_desejada} ${t.unidade_desejada})</span>
                </div>
                <span class="badge-status badge-aberta">Aberta</span>
            </div>
            <p style="font-size:13px; margin:8px 0 4px 0;"><b>Publicado por:</b> ${t.solicitante_nome} &nbsp;|&nbsp; <b>Data:</b> ${dataFmt}</p>
            ${t.observacoes ? `<p style="font-size:12px; color:#777; margin:4px 0;">${t.observacoes}</p>` : ''}
            <div style="margin-top:10px; display:flex; gap:8px; flex-wrap:wrap;">
                <button onclick="aceitarTroca(${t.id_troca})" style="background:#1976d2; width:auto; padding:8px 14px; font-size:13px;">
                    🤝 Tenho Interesse
                </button>
                <a href="https://wa.me/55${t.solicitante_tel}" target="_blank" class="btn-acao btn-whats" style="background:#25d366; padding:8px 14px; font-size:13px; margin-top:0;">
                    💬 WhatsApp
                </a>
            </div>
        </div>`;
    });
}

async function carregarMinhasTrocas() {
    const fd = new FormData();
    fd.append('acao', 'minhas_trocas');
    fd.append('id_user', user.id);
    fd.append('status', document.getElementById('filtro-minhas-trocas-status').value);
    fd.append('mat',    document.getElementById('filtro-minhas-trocas-mat').value);
    fd.append('ordem',  document.getElementById('filtro-minhas-trocas-ordem').value);

    const r = await fetch('salvar.php', { method: 'POST', body: fd });
    const dados = await r.json();
    const lista = document.getElementById('lista-minhas-trocas');

    if (!dados.length) {
        lista.innerHTML = "<p style='text-align:center; padding:20px; color:#666;'>Você ainda não possui trocas registradas.</p>";
        return;
    }

    lista.innerHTML = "";
    dados.forEach(t => {
        const dataFmt = new Date(t.data_troca).toLocaleDateString('pt-BR');
        const ehSolicitante = t.id_solicitante == user.id;
        const statusClass = { 'Aberta':'aberta', 'Aceita':'aceita', 'Concluída':'concluida', 'Cancelada':'cancelada' }[t.status_troca] || 'aberta';
        const badgeClass  = { 'Aberta':'badge-aberta', 'Aceita':'badge-aceita', 'Concluída':'badge-concluida', 'Cancelada':'badge-cancelada' }[t.status_troca] || 'badge-aberta';

        let acoes = '';
        if (ehSolicitante) {
            if (t.status_troca === 'Aceita') {
                acoes = `
                    <button onclick="concluirTroca(${t.id_troca})" style="background:#2e7d32; width:auto; padding:8px 14px; font-size:13px;">
                        ✅ Confirmar Conclusão
                    </button>
                    <button onclick="cancelarTroca(${t.id_troca})" style="background:#d32f2f; width:auto; padding:8px 14px; font-size:13px;">
                        ✖ Cancelar
                    </button>`;
                if (t.recebedor_nome) {
                    acoes += `<p style="font-size:12px; margin-top:8px; color:#1976d2;"><b>Interessado:</b> ${t.recebedor_nome}
                        &nbsp;|&nbsp; <a href="https://wa.me/55${t.recebedor_tel}" target="_blank" style="color:#25d366;">💬 WhatsApp</a></p>`;
                }
            } else if (t.status_troca === 'Aberta') {
                acoes = `<button onclick="cancelarTroca(${t.id_troca})" style="background:#d32f2f; width:auto; padding:8px 14px; font-size:13px;">
                    ✖ Cancelar Proposta
                </button>`;
            }
        } else {
            if (t.status_troca === 'Aceita') {
                acoes = `<p style="font-size:12px; margin-top:8px; color:#1976d2;"><b>Contato do Solicitante:</b> ${t.solicitante_nome}
                    &nbsp;|&nbsp; <a href="https://wa.me/55${t.solicitante_tel}" target="_blank" style="color:#25d366;">💬 WhatsApp</a></p>`;
            }
        }

        lista.innerHTML += `
        <div class="card-troca ${statusClass}">
            <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:6px;">
                <div>
                    <strong style="font-size:15px;">
                        📦 ${t.material_oferecido} (${t.qtd_oferecida} ${t.unidade_oferecida})
                    </strong><br>
                    <span style="font-size:13px; color:#555;">⇅ por <strong>${t.material_desejado}</strong> (${t.qtd_desejada} ${t.unidade_desejada})</span>
                </div>
                <span class="badge-status ${badgeClass}">${t.status_troca}</span>
            </div>
            <p style="font-size:13px; margin:8px 0 4px 0;">
                ${ehSolicitante ? '<b>Você propôs</b>' : `<b>Proposta de:</b> ${t.solicitante_nome}`}
                &nbsp;|&nbsp; <b>Data:</b> ${dataFmt}
            </p>
            ${t.observacoes ? `<p style="font-size:12px; color:#777; margin:4px 0;">${t.observacoes}</p>` : ''}
            <div style="margin-top:10px;">${acoes}</div>
        </div>`;
    });
}

async function aceitarTroca(id_troca) {
    if (!confirm("Confirmar interesse nesta troca? O solicitante verá seu nome e poderá entrar em contato.")) return;
    const fd = new FormData();
    fd.append('acao', 'aceitar_troca');
    fd.append('id_user', user.id);
    fd.append('id_troca', id_troca);
    try {
        const r = await fetch('salvar.php', { method: 'POST', body: fd });
        const res = await r.json();
        alert(res.sucesso || res.erro);
        carregarTrocasAbertas();
        carregarMinhasTrocas();
    } catch(e) { alert("Erro ao aceitar troca."); }
}

async function concluirTroca(id_troca) {
    if (!confirm("Confirmar que a troca foi realizada com sucesso?")) return;
    const fd = new FormData();
    fd.append('acao', 'concluir_troca');
    fd.append('id_user', user.id);
    fd.append('id_troca', id_troca);
    try {
        const r = await fetch('salvar.php', { method: 'POST', body: fd });
        const res = await r.json();
        alert(res.sucesso || res.erro);
        carregarMinhasTrocas();
    } catch(e) { alert("Erro ao concluir troca."); }
}

async function cancelarTroca(id_troca) {
    if (!confirm("Deseja cancelar esta troca?")) return;
    const fd = new FormData();
    fd.append('acao', 'cancelar_troca');
    fd.append('id_user', user.id);
    fd.append('id_troca', id_troca);
    try {
        const r = await fetch('salvar.php', { method: 'POST', body: fd });
        const res = await r.json();
        alert(res.sucesso || res.erro);
        carregarTrocasAbertas();
        carregarMinhasTrocas();
    } catch(e) { alert("Erro ao cancelar troca."); }
}
</script>
</body>
</html>