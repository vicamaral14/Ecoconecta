<?php
class Eco {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function login($email, $senha) {
        $email = $this->conn->real_escape_string($email);
        $sql = "SELECT * FROM USUARIO WHERE email = '$email'";
        $res = $this->conn->query($sql);
        if ($res && $u = $res->fetch_assoc()) {
            if (password_verify($senha, $u['senha'])) {
                return $u;
            }
        }
        return false;
    }

    public function atualizarPerfil($id, $nome, $email, $tel, $end, $senha = null) {
        $nome = $this->conn->real_escape_string($nome);
        $email = $this->conn->real_escape_string($email);
        $tel = preg_replace('/[^0-9]/', '', $tel);
        $end = $this->conn->real_escape_string($end);
        
        $sql = "UPDATE USUARIO SET nome='$nome', email='$email', telefone='$tel', endereco='$end'";
        if (!empty($senha)) {
            $hash = password_hash($senha, PASSWORD_DEFAULT);
            $sql .= ", senha='$hash'";
        }
        $sql .= " WHERE id_usuario = $id";
        return $this->conn->query($sql);
    }

    public function salvarDoacao($id_user, $mat, $mat_custom, $qtd, $unidade, $end, $lat, $lng, $obs, $id_doacao = null, $foto_url = null) {
        $latV = ($lat != 'null' && $lat != '') ? "'$lat'" : "NULL";
        $lngV = ($lng != 'null' && $lng != '') ? "'$lng'" : "NULL";
        $id_mat = ($mat === 'outro') ? "NULL" : (int)$mat;
        $custom = ($mat === 'outro') ? "'" . $this->conn->real_escape_string($mat_custom) . "'" : "NULL";
        $obs = $this->conn->real_escape_string($obs);
        $end = $this->conn->real_escape_string($end);
        $fotoV = (!empty($foto_url)) ? "'" . $this->conn->real_escape_string($foto_url) . "'" : "NULL";

        if ($id_doacao) {
            $fotoSql = (!empty($foto_url)) ? ", foto_url=$fotoV" : "";
            $sql = "UPDATE DOACAO SET id_material=$id_mat, material_personalizado=$custom, quantidade=$qtd, unidade_medida='$unidade', endereco_manual='$end', latitude=$latV, longitude=$lngV, observacoes='$obs'$fotoSql 
                    WHERE id_doacao = $id_doacao AND id_doador = $id_user AND status_doacao = 'Disponível'";
        } else {
            $sql = "INSERT INTO DOACAO (id_doador, id_material, material_personalizado, quantidade, unidade_medida, endereco_manual, latitude, longitude, observacoes, foto_url, status_doacao, data_doacao) 
                    VALUES ($id_user, $id_mat, $custom, $qtd, '$unidade', '$end', $latV, $lngV, '$obs', $fotoV, 'Disponível', NOW())";
        }
        return $this->conn->query($sql);
    }

    public function listarMural($material = 'todos', $cidade = '', $qtd = '', $unidade = 'todos', $ordem = 'recentes') {

    $sql = "SELECT D.*, M.nome_material, U.nome as doador_nome, U.telefone
            FROM DOACAO D
            LEFT JOIN MATERIAL_RECICLAVEL M ON D.id_material = M.id_material
            JOIN USUARIO U ON D.id_doador = U.id_usuario
            WHERE D.status_doacao != 'Coletado'";

    // FILTRO MATERIAL
    if ($material != 'todos') {

        if ($material == 'outro') {
            $sql .= " AND D.id_material IS NULL";
        } else {
            $sql .= " AND D.id_material = " . (int)$material;
        }
    }

    // FILTRO CIDADE
    if (!empty($cidade)) {

        $cidade = $this->conn->real_escape_string($cidade);

        $sql .= " AND D.endereco_manual LIKE '%$cidade%'";
    }

    // FILTRO QUANTIDADE
    if (!empty($qtd)) {

        $qtd = (float)$qtd;

        $sql .= " AND D.quantidade >= $qtd";
    }

    // FILTRO UNIDADE
    if ($unidade != 'todos') {

        $unidade = $this->conn->real_escape_string($unidade);

        $sql .= " AND D.unidade_medida = '$unidade'";
    }

    // ORDENAÇÃO
    if ($ordem == 'quantidade') {

        $sql .= " ORDER BY D.quantidade DESC";

    } else {

        $sql .= " ORDER BY D.data_doacao DESC";
    }

    $res = $this->conn->query($sql);

    $dados = [];

    while($r = $res->fetch_assoc()) {
        $dados[] = $r;
    }

    return $dados;
}

    public function listarMinhasDoacoes($id_user) {
        $sql = "SELECT D.*, M.nome_material FROM DOACAO D LEFT JOIN MATERIAL_RECICLAVEL M ON D.id_material = M.id_material WHERE D.id_doador = $id_user AND D.status_doacao != 'Coletado' ORDER BY D.data_doacao DESC";
        $res = $this->conn->query($sql);
        $dados = [];
        while($r = $res->fetch_assoc()) { $dados[] = $r; }
        return $dados;
    }

    // NOVA FUNÇÃO: Histórico de doações concluídas do doador
    public function listarMinhasDoacoesConcluidas($id_user) {
        $sql = "SELECT D.*, M.nome_material FROM DOACAO D LEFT JOIN MATERIAL_RECICLAVEL M ON D.id_material = M.id_material WHERE D.id_doador = $id_user AND D.status_doacao = 'Coletado' ORDER BY D.data_conclusao_coleta DESC";
        $res = $this->conn->query($sql);
        $dados = [];
        while($r = $res->fetch_assoc()) { $dados[] = $r; }
        return $dados;
    }

    // NOVA FUNÇÃO: Histórico para o Coletor
    public function listarHistoricoColetor($id_coletor) {
        $sql = "SELECT D.*, M.nome_material, U.nome as doador_nome 
                FROM DOACAO D 
                LEFT JOIN MATERIAL_RECICLAVEL M ON D.id_material = M.id_material 
                JOIN USUARIO U ON D.id_doador = U.id_usuario
                WHERE D.id_coletor = $id_coletor AND D.status_doacao = 'Coletado' 
                ORDER BY D.data_conclusao_coleta DESC";
        $res = $this->conn->query($sql);
        $dados = [];
        while($r = $res->fetch_assoc()) { $dados[] = $r; }
        return $dados;
    }

    public function reservarDoacao($id_coletor, $id_doacao, $data_prevista) {
        $data = $this->conn->real_escape_string($data_prevista);
        $sql = "UPDATE DOACAO SET id_coletor = $id_coletor, data_coleta_prevista = '$data', status_doacao = 'Reservado' 
                WHERE id_doacao = $id_doacao AND status_doacao = 'Disponível'";
        return $this->conn->query($sql);
    }

    public function concluirColeta($id_coletor, $id_doacao) {
        $sql = "UPDATE DOACAO SET status_doacao = 'Coletado', data_conclusao_coleta = NOW() 
                WHERE id_doacao = $id_doacao AND id_coletor = $id_coletor";
        return $this->conn->query($sql);
    }

    public function excluirDoacao($id_user, $id_doacao) {
        $sql = "DELETE FROM DOACAO WHERE id_doacao = $id_doacao AND id_doador = $id_user AND status_doacao = 'Disponível'";
        return $this->conn->query($sql);
    }

    public function excluirPerfil($id) {
        $this->conn->query("DELETE FROM DOACAO WHERE id_doador = $id OR id_coletor = $id");
        return $this->conn->query("DELETE FROM USUARIO WHERE id_usuario = $id");
    }

    public function listarMateriais() {
        $res = $this->conn->query("SELECT * FROM MATERIAL_RECICLAVEL ORDER BY nome_material ASC");
        $dados = [];
        while($r = $res->fetch_assoc()) { $dados[] = $r; }
        return $dados;
    }

    public function salvarMaterial($nome, $id = null) {
        $nome = $this->conn->real_escape_string($nome);
        if($id) return $this->conn->query("UPDATE MATERIAL_RECICLAVEL SET nome_material='$nome' WHERE id_material=$id");
        return $this->conn->query("INSERT INTO MATERIAL_RECICLAVEL (nome_material) VALUES ('$nome')");
    }

    public function excluirMaterial($id) {
        return $this->conn->query("DELETE FROM MATERIAL_RECICLAVEL WHERE id_material = $id");
    }

    // =====================================================
    // FUNÇÕES DE TROCA DE MATERIAIS
    // =====================================================

    /**
     * Registra uma nova proposta de troca de material
     */
    public function registrarTroca($id_solicitante, $mat_oferecido, $qtd_oferecida, $unidade_oferecida, $mat_desejado, $qtd_desejada, $unidade_desejada, $obs) {
        $mat_oferecido  = $this->conn->real_escape_string($mat_oferecido);
        $mat_desejado   = $this->conn->real_escape_string($mat_desejado);
        $obs            = $this->conn->real_escape_string($obs);
        $qtd_oferecida  = (float)$qtd_oferecida;
        $qtd_desejada   = (float)$qtd_desejada;
        $unidade_oferecida = $this->conn->real_escape_string($unidade_oferecida);
        $unidade_desejada  = $this->conn->real_escape_string($unidade_desejada);

        $sql = "INSERT INTO TROCA_MATERIAL 
                    (id_solicitante, material_oferecido, qtd_oferecida, unidade_oferecida, material_desejado, qtd_desejada, unidade_desejada, observacoes, status_troca, data_troca)
                VALUES 
                    ($id_solicitante, '$mat_oferecido', $qtd_oferecida, '$unidade_oferecida', '$mat_desejado', $qtd_desejada, '$unidade_desejada', '$obs', 'Aberta', NOW())";
        return $this->conn->query($sql);
    }

    /**
     * Lista todas as trocas abertas (mural de trocas), exceto as do próprio usuário
     */
    public function listarTrocasAbertas($id_user, $mat_oferecido = '', $mat_desejado = '', $unidade = 'todos', $ordem = 'recentes') {
        $sql = "SELECT T.*, U.nome as solicitante_nome, U.telefone as solicitante_tel
                FROM TROCA_MATERIAL T
                JOIN USUARIO U ON T.id_solicitante = U.id_usuario
                WHERE T.status_troca = 'Aberta' AND T.id_solicitante != $id_user";

        if (!empty($mat_oferecido)) {
            $mat_oferecido = $this->conn->real_escape_string($mat_oferecido);
            $sql .= " AND T.material_oferecido LIKE '%$mat_oferecido%'";
        }
        if (!empty($mat_desejado)) {
            $mat_desejado = $this->conn->real_escape_string($mat_desejado);
            $sql .= " AND T.material_desejado LIKE '%$mat_desejado%'";
        }
        if ($unidade !== 'todos') {
            $unidade = $this->conn->real_escape_string($unidade);
            $sql .= " AND (T.unidade_oferecida = '$unidade' OR T.unidade_desejada = '$unidade')";
        }

        $sql .= ($ordem === 'quantidade') ? " ORDER BY T.qtd_oferecida DESC" : " ORDER BY T.data_troca DESC";

        $res = $this->conn->query($sql);
        $dados = [];
        while($r = $res->fetch_assoc()) { $dados[] = $r; }
        return $dados;
    }

    /**
     * Lista as trocas do próprio usuário (tanto as que ele propôs quanto as que aceitou)
     */
    public function listarMinhasTrocas($id_user, $status = 'todos', $mat = '', $ordem = 'recentes') {
        $sql = "SELECT T.*,
                    U1.nome as solicitante_nome, U1.telefone as solicitante_tel,
                    U2.nome as recebedor_nome, U2.telefone as recebedor_tel
                FROM TROCA_MATERIAL T
                JOIN USUARIO U1 ON T.id_solicitante = U1.id_usuario
                LEFT JOIN USUARIO U2 ON T.id_recebedor = U2.id_usuario
                WHERE (T.id_solicitante = $id_user OR T.id_recebedor = $id_user)";

        if ($status !== 'todos') {
            $status = $this->conn->real_escape_string($status);
            $sql .= " AND T.status_troca = '$status'";
        }
        if (!empty($mat)) {
            $mat = $this->conn->real_escape_string($mat);
            $sql .= " AND (T.material_oferecido LIKE '%$mat%' OR T.material_desejado LIKE '%$mat%')";
        }

        $sql .= ($ordem === 'quantidade') ? " ORDER BY T.qtd_oferecida DESC" : " ORDER BY T.data_troca DESC";

        $res = $this->conn->query($sql);
        $dados = [];
        while($r = $res->fetch_assoc()) { $dados[] = $r; }
        return $dados;
    }

    /**
     * Aceita uma troca aberta (outro usuário demonstra interesse)
     */
    public function aceitarTroca($id_recebedor, $id_troca) {
        $sql = "UPDATE TROCA_MATERIAL SET id_recebedor = $id_recebedor, status_troca = 'Aceita'
                WHERE id_troca = $id_troca AND status_troca = 'Aberta' AND id_solicitante != $id_recebedor";
        return $this->conn->query($sql);
    }

    /**
     * Conclui uma troca (somente o solicitante pode confirmar a conclusão)
     */
    public function concluirTroca($id_solicitante, $id_troca) {
        $sql = "UPDATE TROCA_MATERIAL SET status_troca = 'Concluída', data_conclusao = NOW()
                WHERE id_troca = $id_troca AND id_solicitante = $id_solicitante AND status_troca = 'Aceita'";
        return $this->conn->query($sql);
    }

    /**
     * Cancela uma troca (somente o solicitante pode cancelar enquanto Aberta ou Aceita)
     */
    public function cancelarTroca($id_solicitante, $id_troca) {
        $sql = "UPDATE TROCA_MATERIAL SET status_troca = 'Cancelada'
                WHERE id_troca = $id_troca AND id_solicitante = $id_solicitante AND status_troca IN ('Aberta','Aceita')";
        return $this->conn->query($sql);
    }
}
?>