<?php
header('Content-Type: application/json');
include 'conexao.php';
include 'Eco.php';

$eco = new Eco($conn);
$acao = $_POST['acao'] ?? '';

if ($acao == 'login') {
    $res = $eco->login($_POST['email'], $_POST['senha']);
    echo $res ? json_encode($res) : json_encode(["erro" => "E-mail ou senha incorretos."]);
} 
elseif ($acao == 'cadastro') {
    $nome = $conn->real_escape_string($_POST['nome']);
    $email = $conn->real_escape_string($_POST['email']);
    $doc = preg_replace('/[^0-9]/', '', $_POST['doc']);
    $tel = preg_replace('/[^0-9]/', '', $_POST['tel']);
    $end = $conn->real_escape_string($_POST['end']);
    $tipo = $_POST['tipo']; 
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);
    
    $sql = "INSERT INTO USUARIO (nome, email, documento, telefone, endereco, tipo_usuario, senha, status, data_cadastro) 
            VALUES ('$nome', '$email', '$doc', '$tel', '$end', '$tipo', '$senha', 'Ativo', NOW())";
    
    echo $conn->query($sql) ? json_encode(["sucesso" => "✅ Cadastro realizado!"]) : json_encode(["erro" => $conn->error]);
}
elseif ($acao == 'perfil_update') {
    $res = $eco->atualizarPerfil($_POST['id'], $_POST['nome'], $_POST['email'], $_POST['tel'], $_POST['end'], $_POST['senha']);
    echo json_encode($res ? ["sucesso" => "✅ Perfil updated!"] : ["erro" => "Erro ao atualizar"]);
}
elseif ($acao == 'perfil_excluir') {
    echo json_encode($eco->excluirPerfil($_POST['id']) ? ["sucesso" => "Conta excluída."] : ["erro" => "Erro"]);
}
elseif ($acao == 'doacao') {
    $foto_url = null;

    if (!empty($_FILES['foto']['tmp_name'])) {
        // Caminho absoluto — garante funcionamento no XAMPP independente do diretório de trabalho
        $uploadDir = __DIR__ . '/uploads/fotos/';

        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $ext = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

        if (!in_array($ext, $allowed)) {
            echo json_encode(["erro" => "Formato de imagem não permitido. Use JPG, PNG, GIF ou WEBP."]);
            exit;
        }

        if ($_FILES['foto']['size'] > 5 * 1024 * 1024) {
            echo json_encode(["erro" => "Imagem muito grande. O limite é 5 MB."]);
            exit;
        }

        if ($_FILES['foto']['error'] !== UPLOAD_ERR_OK) {
            $erros = [
                UPLOAD_ERR_INI_SIZE   => 'Arquivo excede upload_max_filesize no php.ini',
                UPLOAD_ERR_FORM_SIZE  => 'Arquivo excede MAX_FILE_SIZE do formulário',
                UPLOAD_ERR_PARTIAL    => 'Upload parcial',
                UPLOAD_ERR_NO_FILE    => 'Nenhum arquivo enviado',
                UPLOAD_ERR_NO_TMP_DIR => 'Pasta temporária ausente',
                UPLOAD_ERR_CANT_WRITE => 'Falha ao escrever no disco',
                UPLOAD_ERR_EXTENSION  => 'Upload bloqueado por extensão PHP',
            ];
            $msg = $erros[$_FILES['foto']['error']] ?? 'Erro desconhecido no upload (código ' . $_FILES['foto']['error'] . ')';
            echo json_encode(["erro" => "Erro no envio da foto: $msg"]);
            exit;
        }

        $nome = uniqid('foto_', true) . '.' . $ext;
        $destino = $uploadDir . $nome;

        if (move_uploaded_file($_FILES['foto']['tmp_name'], $destino)) {
            // Caminho relativo salvo no banco — usado como src no HTML
            $foto_url = 'uploads/fotos/' . $nome;
        } else {
            echo json_encode(["erro" => "Falha ao mover o arquivo para uploads/fotos/. Verifique as permissões da pasta."]);
            exit;
        }
    }

    $res = $eco->salvarDoacao(
        $_POST['id_user'],
        $_POST['mat'],
        $_POST['mat_custom'],
        $_POST['qtd'],
        $_POST['unidade'],
        $_POST['end'],
        $_POST['lat'],
        $_POST['lng'],
        $_POST['obs'],
        $_POST['id_doacao'] ?? null,
        $foto_url
    );
    echo json_encode($res ? ["sucesso" => "✅ Operação realizada!"] : ["erro" => "Erro ao salvar: " . $conn->error]);
}
elseif ($acao == 'excluir_doacao') {
    echo json_encode($eco->excluirDoacao($_POST['id_user'], $_POST['id_doacao']) ? ["sucesso" => "Excluído!"] : ["erro" => "Erro"]);
}
elseif ($acao == 'reservar') {
    echo json_encode($eco->reservarDoacao($_POST['id_user'], $_POST['id_doacao'], $_POST['data']) ? ["sucesso" => "Reservado!"] : ["erro" => "Erro"]);
}
elseif ($acao == 'concluir') {
    echo json_encode($eco->concluirColeta($_POST['id_user'], $_POST['id_doacao']) ? ["sucesso" => "Concluído!"] : ["erro" => "Erro"]);
}
elseif ($acao == 'minhas_doacoes') {
    echo json_encode($eco->listarMinhasDoacoes($_POST['id_user']));
}
elseif ($acao == 'minhas_doacoes_concluidas') {
    echo json_encode($eco->listarMinhasDoacoesConcluidas($_POST['id_user']));
}
elseif ($acao == 'historico_coletor') {
    echo json_encode($eco->listarHistoricoColetor($_POST['id_user']));
}
elseif ($acao == 'buscar_mural') {
    $material = $_POST['material'] ?? 'todos';
    $cidade   = $_POST['cidade']   ?? '';
    $qtd      = $_POST['qtd']      ?? '';
    $unidade  = $_POST['unidade']  ?? 'todos';
    $ordem    = $_POST['ordem']    ?? 'recentes';
    echo json_encode($eco->listarMural($material, $cidade, $qtd, $unidade, $ordem));
}
elseif ($acao == 'adm_listar_materiais') {
    echo json_encode($eco->listarMateriais());
}
elseif ($acao == 'adm_salvar_material') {
    echo json_encode($eco->salvarMaterial($_POST['nome']) ? ["sucesso" => true] : ["erro" => true]);
}
elseif ($acao == 'adm_excluir_material') {
    echo json_encode($eco->excluirMaterial($_POST['id']) ? ["sucesso" => true] : ["erro" => true]);
}

// =====================================================
// CASOS DE TROCA DE MATERIAIS
// =====================================================

elseif ($acao == 'registrar_troca') {
    $res = $eco->registrarTroca(
        $_POST['id_user'],
        $_POST['mat_oferecido'],
        $_POST['qtd_oferecida'],
        $_POST['unidade_oferecida'],
        $_POST['mat_desejado'],
        $_POST['qtd_desejada'],
        $_POST['unidade_desejada'],
        $_POST['obs'] ?? ''
    );
    echo json_encode($res ? ["sucesso" => "✅ Troca registrada com sucesso!"] : ["erro" => "Erro ao registrar troca."]);
}
elseif ($acao == 'listar_trocas_abertas') {
    $mat_oferecido = $_POST['mat_oferecido'] ?? '';
    $mat_desejado  = $_POST['mat_desejado']  ?? '';
    $unidade       = $_POST['unidade']       ?? 'todos';
    $ordem         = $_POST['ordem']         ?? 'recentes';
    echo json_encode($eco->listarTrocasAbertas($_POST['id_user'], $mat_oferecido, $mat_desejado, $unidade, $ordem));
}
elseif ($acao == 'minhas_trocas') {
    $status = $_POST['status'] ?? 'todos';
    $mat    = $_POST['mat']    ?? '';
    $ordem  = $_POST['ordem']  ?? 'recentes';
    echo json_encode($eco->listarMinhasTrocas($_POST['id_user'], $status, $mat, $ordem));
}
elseif ($acao == 'aceitar_troca') {
    $res = $eco->aceitarTroca($_POST['id_user'], $_POST['id_troca']);
    echo json_encode($res ? ["sucesso" => "✅ Interesse registrado! Entre em contato com o solicitante."] : ["erro" => "Não foi possível aceitar esta troca."]);
}
elseif ($acao == 'concluir_troca') {
    $res = $eco->concluirTroca($_POST['id_user'], $_POST['id_troca']);
    echo json_encode($res ? ["sucesso" => "✅ Troca concluída!"] : ["erro" => "Erro ao concluir troca."]);
}
elseif ($acao == 'cancelar_troca') {
    $res = $eco->cancelarTroca($_POST['id_user'], $_POST['id_troca']);
    echo json_encode($res ? ["sucesso" => "Troca cancelada."] : ["erro" => "Erro ao cancelar troca."]);
}
?>